"""وكيل تلخيص النصوص والمحتوى الذي يقدمه المستخدم."""
from agno.agent import Agent
from agno.models.google import Gemini
import os

def build_summary_agent() -> Agent:
    return Agent(
        id="summary-agent",
        name="Summary Agent",
        role="تلخيص النصوص والمستندات والمحتوى المتاح",
        model=Gemini(id=os.getenv("GEMINI_MODEL", "gemini-2.5-flash")),
        instructions=[
            "لخّص النص الذي يرسله المستخدم بدقة دون إضافة معلومات غير موجودة.",
            "إذا أرسل المستخدم رابطًا لا تستطيع الأدوات الوصول إليه، اطلب منه لصق النص أو رفع الملف.",
            "قدّم ملخصًا تنفيذيًا ثم النقاط الرئيسية والقرارات والمخاطر والأسئلة المفتوحة.",
            "حافظ على الأسماء والتواريخ والأرقام والتحفظات المهمة.",
            "اكتب بالعربية ما لم يطلب المستخدم لغة أخرى.",
        ],
        markdown=True,
    )

summary_agent = build_summary_agent()
