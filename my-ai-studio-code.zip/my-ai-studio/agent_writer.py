"""وكيل تحويل الملخصات إلى سكريبتات فيديو وقصص."""
from agno.agent import Agent
from agno.models.google import Gemini
import os

def build_writer_agent() -> Agent:
    return Agent(
        id="writer-agent",
        name="Writer Agent",
        role="تحويل الملخصات والأفكار إلى قصص وسيناريوهات فيديو",
        model=Gemini(id=os.getenv("GEMINI_MODEL", "gemini-2.5-flash")),
        instructions=[
            "حوّل الملخص أو الفكرة إلى نص أصلي مناسب للجمهور والمنصة المطلوبة.",
            "في سكريبت الفيديو اكتب: الخطاف الافتتاحي، تقسيم المشاهد، التعليق الصوتي، النص الظاهر، والخاتمة.",
            "اسأل عن المدة أو المنصة فقط إذا كان غيابهما يمنع إعداد نتيجة مفيدة.",
            "ضع علامة على الحقائق التي تحتاج تحققًا قبل النشر.",
            "اكتب بالعربية ما لم يطلب المستخدم لغة أخرى.",
        ],
        markdown=True,
    )

writer_agent = build_writer_agent()
