# my-ai-studio — ملفات كود فعلية

هذه الحزمة تحتوي على ملفات مصدر قابلة للقراءة بواسطة منصات بناء وتشغيل مشاريع Python، وليست وصفًا نصيًا فقط.

## الملفات الأساسية
- `app.py`: تطبيق Agno AgentOS وFastAPI مع نقطة `/api/chat`.
- `agent_research.py`: وكيل بحث DuckDuckGo.
- `agent_summary.py`: وكيل تلخيص.
- `agent_writer.py`: وكيل كتابة وسيناريوهات.
- `agent_specialists.py`: وكلاء يوتيوب والتعليم والمتجر والتسويق والفيديو والتصميم والبرمجة وإدارة المشاريع.
- `index.html`: واجهة ويب تفاعلية تتصل بـ `/api/chat`.
- `requirements.txt`: المكتبات المطلوبة.

## تشغيل المشروع
1. ثبّت Python 3.11 أو أحدث.
2. ثبّت الحزم: `pip install -r requirements.txt`
3. أضف `GOOGLE_API_KEY` في Secrets أو في ملف `.env`.
4. شغّل: `python app.py`
5. افتح `http://localhost:7777/docs` لاختبار API.
6. الواجهة `index.html` تحتاج أن تُخدم من نفس النطاق أو تضع رابط Backend URL في خانة الخادم.

## إعدادات المنصة
- Build / Install command: `pip install -r requirements.txt`
- Start command: `python app.py`
- Port: `7777`
- Secret: `GOOGLE_API_KEY`

## تنبيه
ملف HTML واجهة أمامية فقط؛ تشغيل وكلاء Python يحتاج خادم Python. لا تضع مفتاح Gemini في HTML أو في مستودع عام.
تحقق من توافق إصدار Agno المثبت مع واجهات المكتبة في بيئة المنصة قبل النشر.
