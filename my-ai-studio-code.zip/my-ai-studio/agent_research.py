"""وكيل البحث على الإنترنت باستخدام DuckDuckGo وGemini."""
from agno.agent import Agent
from agno.models.google import Gemini
from agno.tools.duckduckgo import DuckDuckGoTools
import os

def build_research_agent() -> Agent:
    return Agent(
        id="research-agent",
        name="Research Agent",
        role="البحث في الإنترنت وجمع المعلومات ومقارنة المصادر",
        model=Gemini(id=os.getenv("GEMINI_MODEL", "gemini-2.5-flash")),
        tools=[DuckDuckGoTools()],
        instructions=[
            "ابحث باستخدام DuckDuckGo عندما يطلب المستخدم معلومات حديثة أو مصادر.",
            "اعرض أهم النتائج مع روابط المصادر المتاحة.",
            "فرّق بين الحقائق المؤكدة والتقديرات والآراء.",
            "لا تختلق مصادر أو روابط أو نتائج بحث.",
            "اكتب بالعربية ما لم يطلب المستخدم لغة أخرى.",
        ],
        markdown=True,
    )

research_agent = build_research_agent()
