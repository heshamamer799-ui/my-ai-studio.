# MALEK AI YouTube Factory
# Version: 1.0
# First module: Create and save a video project (offline).

import json
from pathlib import Path
from datetime import datetime

PROJECTS_FOLDER = Path("projects")

def create_project(title, idea, video_type, projects_folder=PROJECTS_FOLDER):
    """Create a video project and save its details as UTF-8 JSON."""
    title = title.strip()
    idea = idea.strip()

    if not title:
        raise ValueError("عنوان الفيديو لا يمكن أن يكون فارغًا.")
    if not idea:
        raise ValueError("فكرة الفيديو لا يمكن أن تكون فارغة.")
    if video_type not in ("Shorts", "Long Video"):
        raise ValueError("نوع الفيديو يجب أن يكون Shorts أو Long Video.")

    projects_folder = Path(projects_folder)
    projects_folder.mkdir(parents=True, exist_ok=True)

    now = datetime.now()
    project = {
        "studio": "MALEK AI",
        "version": "1.0",
        "title": title,
        "idea": idea,
        "video_type": video_type,
        "created_at": now.isoformat(timespec="seconds"),
        "status": "Created - awaiting production",
        "approved_for_publishing": False
    }

    filename = now.strftime("project_%Y%m%d_%H%M%S_%f.json")
    filepath = projects_folder / filename

    with filepath.open("w", encoding="utf-8") as file:
        json.dump(project, file, ensure_ascii=False, indent=4)

    return filepath, project


def main():
    print("\n===== MALEK AI YOUTUBE FACTORY =====")
    title = input("اكتب عنوان الفيديو: ")
    idea = input("اكتب فكرة الفيديو: ")

    print("\nاختر نوع الفيديو:")
    print("1 - YouTube Shorts")
    print("2 - YouTube Long Video")
    choice = input("اكتب 1 أو 2: ").strip()

    video_type = {"1": "Shorts", "2": "Long Video"}.get(choice)
    if video_type is None:
        print("اختيار غير صحيح. شغّل البرنامج مرة أخرى واختر 1 أو 2.")
        return

    try:
        filepath, project = create_project(title, idea, video_type)
    except ValueError as error:
        print(f"لم يتم إنشاء المشروع: {error}")
        return

    print("\nتم إنشاء المشروع بنجاح!")
    print("العنوان:", project["title"])
    print("النوع:", project["video_type"])
    print("ملف الحفظ:", filepath)
    print("النشر: متوقف حتى موافقتك")


if __name__ == "__main__":
    main()
