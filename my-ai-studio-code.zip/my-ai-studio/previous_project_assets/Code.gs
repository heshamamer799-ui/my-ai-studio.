/**
 * INFlow Personal AI Studio — Phase 1
 * Secure ZIP intake and Google Drive file storage.
 * Storage is private to the deploying Google account unless Drive sharing is changed manually.
 */

const APP_CONFIG = Object.freeze({
  APP_NAME: 'INFlow Personal AI Studio',
  FOLDER_NAME: 'INFlow Personal AI Studio - Files',
  FOLDER_ID_PROPERTY: 'INFLOW_STORAGE_FOLDER_ID',
  MAX_ZIP_BYTES: 10 * 1024 * 1024,       // 10 MB compressed upload
  MAX_FILES: 100,                        // maximum extracted files
  MAX_FILE_BYTES: 10 * 1024 * 1024,     // maximum individual extracted file
  MAX_TOTAL_BYTES: 40 * 1024 * 1024    // maximum total extracted content
});

function doGet() {
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle(APP_CONFIG.APP_NAME)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

/** Returns basic app/storage status for the dashboard. */
function getAppStatus() {
  const folder = getStorageFolder_();
  const files = folder.getFiles();
  let count = 0;
  while (files.hasNext()) {
    files.next();
    count++;
  }
  return {
    appName: APP_CONFIG.APP_NAME,
    folderName: folder.getName(),
    folderUrl: folder.getUrl(),
    fileCount: count,
    limits: {
      maxZipMB: APP_CONFIG.MAX_ZIP_BYTES / 1024 / 1024,
      maxFiles: APP_CONFIG.MAX_FILES,
      maxFileMB: APP_CONFIG.MAX_FILE_BYTES / 1024 / 1024,
      maxTotalMB: APP_CONFIG.MAX_TOTAL_BYTES / 1024 / 1024
    }
  };
}

/**
 * Accepts a base64 ZIP, validates all entries, then saves them to the private Drive folder.
 * Existing files are never overwritten; duplicate names receive a numbered suffix.
 */
function uploadZip(base64Data, originalName) {
  if (typeof base64Data !== 'string' || !base64Data.trim()) {
    throw new Error('لم يصل أي ملف. اختر ملف ZIP ثم حاول مرة أخرى.');
  }

  const cleanBase64 = base64Data.replace(/^data:[^,]*;base64,/, '').replace(/\s/g, '');
  // Check encoded size before decoding to avoid unnecessary memory use.
  const estimatedBytes = Math.floor(cleanBase64.length * 3 / 4);
  if (estimatedBytes <= 0 || estimatedBytes > APP_CONFIG.MAX_ZIP_BYTES + 3) {
    throw new Error('حجم ملف ZIP يتجاوز الحد المسموح وهو 10 ميجابايت.');
  }

  const zipName = String(originalName || 'upload.zip');
  if (!/\.zip$/i.test(zipName) || zipName.length > 180) {
    throw new Error('اسم الملف غير صالح أو أن الملف ليس بصيغة ZIP.');
  }

  let bytes;
  try {
    bytes = Utilities.base64Decode(cleanBase64);
  } catch (e) {
    throw new Error('تعذر قراءة بيانات الملف. أعد اختيار ملف ZIP.');
  }
  if (!bytes.length || bytes.length > APP_CONFIG.MAX_ZIP_BYTES) {
    throw new Error('حجم ملف ZIP يتجاوز الحد المسموح وهو 10 ميجابايت.');
  }
  if (!hasZipSignature_(bytes)) {
    throw new Error('محتوى الملف لا يبدو كملف ZIP صالح.');
  }

  let entries;
  try {
    entries = Utilities.unzip(Utilities.newBlob(bytes, 'application/zip', 'upload.zip'));
  } catch (e) {
    throw new Error('فشل فك ضغط الملف. تأكد من سلامة ملف ZIP وأنه غير محمي بكلمة مرور.');
  }
  if (!entries || !entries.length) {
    throw new Error('ملف ZIP لا يحتوي على ملفات قابلة للاستخراج.');
  }

  // Validate the complete archive before writing anything to Drive.
  const accepted = [];
  let totalBytes = 0;
  entries.forEach(function(blob) {
    const rawName = String(blob.getName() || '');
    if (!rawName || /[\u0000-\u001f\u007f]/.test(rawName)) return;

    const normalized = rawName.replace(/\\/g, '/');
    if (normalized.endsWith('/')) return; // directory entry
    const parts = normalized.split('/');
    if (normalized.charAt(0) === '/' || /^[A-Za-z]:/.test(normalized) || parts.indexOf('..') !== -1) {
      throw new Error('يحتوي الأرشيف على مسار غير آمن. لم يتم حفظ أي ملف.');
    }

    const leaf = parts[parts.length - 1];
    if (!leaf || leaf.charAt(0) === '.') return; // ignore hidden/system files
    const safeName = sanitizeFileName_(leaf);
    if (!safeName) return;

    const size = blob.getBytes().length;
    if (size > APP_CONFIG.MAX_FILE_BYTES) {
      throw new Error('يوجد ملف داخل ZIP أكبر من 10 ميجابايت. لم يتم حفظ أي ملف.');
    }
    totalBytes += size;
    if (totalBytes > APP_CONFIG.MAX_TOTAL_BYTES) {
      throw new Error('إجمالي الملفات بعد فك الضغط يتجاوز 40 ميجابايت. لم يتم حفظ أي ملف.');
    }
    accepted.push({ blob: blob, name: safeName, size: size });
    if (accepted.length > APP_CONFIG.MAX_FILES) {
      throw new Error('عدد الملفات داخل ZIP يتجاوز الحد وهو 100 ملف. لم يتم حفظ أي ملف.');
    }
  });

  if (!accepted.length) {
    throw new Error('لم نعثر على ملفات عادية للحفظ. قد يحتوي الأرشيف على مجلدات أو ملفات مخفية فقط.');
  }

  const folder = getStorageFolder_();
  const usedNames = getExistingNames_(folder);
  const createdFiles = [];
  try {
    accepted.forEach(function(item) {
      const uniqueName = makeUniqueName_(item.name, usedNames);
      const saved = folder.createFile(item.blob.setName(uniqueName));
      createdFiles.push(saved);
    });
  } catch (e) {
    // Roll back this batch if Drive fails part-way through.
    createdFiles.forEach(function(file) {
      try { file.setTrashed(true); } catch (ignored) {}
    });
    throw new Error('تعذر حفظ الملفات في Google Drive. لم نحتفظ بالرفع الجزئي. تحقق من مساحة Drive والصلاحيات ثم حاول مجدداً.');
  }

  return {
    success: true,
    folderName: folder.getName(),
    folderUrl: folder.getUrl(),
    count: createdFiles.length,
    totalBytes: totalBytes,
    files: createdFiles.map(function(file) {
      return { name: file.getName(), id: file.getId(), url: file.getUrl(), mimeType: file.getMimeType(), size: file.getSize() };
    })
  };
}

/** Lists files stored by this app. */
function listUploadedFiles() {
  const folder = getStorageFolder_();
  const iterator = folder.getFiles();
  const files = [];
  while (iterator.hasNext()) {
    const file = iterator.next();
    files.push({
      name: file.getName(), id: file.getId(), url: file.getUrl(),
      mimeType: file.getMimeType(), size: file.getSize(),
      updated: file.getLastUpdated().toISOString()
    });
  }
  files.sort(function(a, b) { return a.name.localeCompare(b.name); });
  return { folderName: folder.getName(), folderUrl: folder.getUrl(), files: files };
}

/** Uses a saved folder ID to avoid accidentally selecting an unrelated same-name folder. */
function getStorageFolder_() {
  const props = PropertiesService.getScriptProperties();
  const savedId = props.getProperty(APP_CONFIG.FOLDER_ID_PROPERTY);
  if (savedId) {
    try {
      const savedFolder = DriveApp.getFolderById(savedId);
      if (!savedFolder.isTrashed()) return savedFolder;
    } catch (e) {
      // The folder may have been deleted or access revoked; create a new one below.
    }
  }
  const folder = DriveApp.createFolder(APP_CONFIG.FOLDER_NAME);
  props.setProperty(APP_CONFIG.FOLDER_ID_PROPERTY, folder.getId());
  return folder;
}

function getExistingNames_(folder) {
  const names = Object.create(null);
  const iterator = folder.getFiles();
  while (iterator.hasNext()) names[iterator.next().getName()] = true;
  return names;
}

function makeUniqueName_(name, usedNames) {
  if (!usedNames[name]) {
    usedNames[name] = true;
    return name;
  }
  const dot = name.lastIndexOf('.');
  const base = dot > 0 ? name.substring(0, dot) : name;
  const ext = dot > 0 ? name.substring(dot) : '';
  let index = 2;
  let candidate = base + ' (' + index + ')' + ext;
  while (usedNames[candidate]) {
    index++;
    candidate = base + ' (' + index + ')' + ext;
  }
  usedNames[candidate] = true;
  return candidate;
}

function sanitizeFileName_(name) {
  return String(name)
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .trim()
    .substring(0, 180);
}

function hasZipSignature_(bytes) {
  return bytes.length >= 4 && bytes[0] === 80 && bytes[1] === 75 &&
    ((bytes[2] === 3 && bytes[3] === 4) ||
     (bytes[2] === 5 && bytes[3] === 6) ||
     (bytes[2] === 7 && bytes[3] === 8));
}
