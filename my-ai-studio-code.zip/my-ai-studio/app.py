"""الملف الرئيسي: يربط الوكلاء بفريق Agno ويشغّل AgentOS وواجهة API."""
from pathlib import Path
import os
from dotenv import load_dotenv
from fastapi import HTTPException
from pydantic import BaseModel

load_dotenv()

if not os.getenv("GOOGLE_API_KEY"):
    raise RuntimeError(
        "GOOGLE_API_KEY غير موجود. أضف المفتاح في Secrets بالمنصة "
        "أو أنشئ ملف .env محليًا اعتمادًا على .env.example."
    )

from agno.db.sqlite import SqliteDb
from agno.os import AgentOS
from agno.team import Team

from agent_research import research_agent
from agent_summary import summary_agent
from agent_writer import writer_agent
from agent_specialists import (
    youtube_agent, education_agent, store_agent, marketing_agent,
    video_agent, design_agent, coding_agent, project_agent,
)

BASE_DIR = Path(__file__).resolve().parent
STORAGE_DIR = BASE_DIR / "storage"
STORAGE_DIR.mkdir(exist_ok=True)
database = SqliteDb(db_file=str(STORAGE_DIR / "my_ai_studio.db"))

studio_team = Team(
    id="my-ai-studio-team",
    name="My AI Studio Team",
    model=research_agent.model,
    members=[
        research_agent, summary_agent, writer_agent, youtube_agent,
        education_agent, store_agent, marketing_agent, video_agent,
        design_agent, coding_agent, project_agent,
    ],
    instructions=[
        "أنت مدير فريق استوديو ذكاء اصطناعي شخصي.",
        "وزّع أجزاء الطلب على الوكلاء المتخصصين المناسبين ثم اجمع النتائج في إجابة واحدة.",
        "استخدم البحث عند الحاجة إلى معلومات حديثة أو مصادر.",
        "لا تدّعِ تنفيذ نشر أو شراء أو رفع ملفات أو تحرير وسائط دون أداة متصلة تؤكد التنفيذ.",
        "اطلب موافقة المستخدم قبل أي إجراء خارجي أو حساس أو غير قابل للتراجع.",
        "أجب بالعربية افتراضيًا.",
    ],
    markdown=True,
)

agent_os = AgentOS(
    id="my-ai-studio",
    name="My AI Studio",
    description="فريق شخصي من وكلاء الذكاء الاصطناعي باستخدام Agno وGemini",
    agents=[research_agent, summary_agent, writer_agent],
    teams=[studio_team],
    db=database,
    tracing=False,
)
app = agent_os.get_app()

class ChatRequest(BaseModel):
    message: str

@app.get("/api/health")
def health():
    return {"status": "ok", "project": "my-ai-studio"}

@app.post("/api/chat")
def chat(payload: ChatRequest):
    prompt = payload.message.strip()
    if not prompt:
        raise HTTPException(status_code=400, detail="اكتب طلبًا أولًا.")
    try:
        result = studio_team.run(prompt)
        content = getattr(result, "content", None)
        return {"reply": str(content if content is not None else result)}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"حدث خطأ أثناء تشغيل الفريق: {exc}")

if __name__ == "__main__":
    agent_os.serve(
        app="app:app",
        host=os.getenv("AGENT_OS_HOST", "0.0.0.0"),
        port=int(os.getenv("AGENT_OS_PORT", "7777")),
        reload=False,
    )
